package com.amazonaws.lambda.rds;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvocationType;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
public class LambdaFunctionHandlerTest {

	private static String input;

	@BeforeClass
	public static void createInput() throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		/*
		 * TestJsonData tjd = new TestJsonData(); tjd.setDbname("fskTest");
		 * tjd.setPassword("14003352"); tjd.setQuery("select * from persons");
		 * tjd.setUsername("fsk")
		 */;
		String json = "{\"username\": \"fsk\",\"password\": \"14003352\",\"dbname\": \"fskTest\",\"query\": \"select Lastname from persons\"}";
		//input = mapper.readValue(new File("test.json"), String.class);
		input = json;
		// input = mapper.readValue(json, JsonNode.class);
	}

	//@Test
	public void testhandler() throws IOException {
		LambdaFunctionHandler hand = new LambdaFunctionHandler();
		TestContext cxt = new TestContext();
		hand.handleRequest(input, cxt);
	}

	@Test
	public void invokeLambda() throws IOException {
		final String AWS_ACCESS_KEY_ID = "AKIAV3Z2KDBHYOT6BWWA";
		final String AWS_SECRET_ACCESS_KEY = "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";

		AWSCredentials credentials = new BasicAWSCredentials(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY);
		// ARN
		String functionName = "arn:aws:lambda:ap-south-1:403312351311:function:DBConnector";
		InvokeRequest lmbRequest = new InvokeRequest().withFunctionName(functionName).withPayload(input);

		lmbRequest.setInvocationType(InvocationType.RequestResponse);

		AWSLambda lambda = AWSLambdaClientBuilder.standard().withRegion(Regions.AP_SOUTH_1)
				.withCredentials(new AWSStaticCredentialsProvider(credentials)).build();

		InvokeResult lmbResult = lambda.invoke(lmbRequest);

		String resultJSON = new String(lmbResult.getPayload().array(), Charset.forName("UTF-8"));

		System.out.println(resultJSON);
	}
}

package com.amazonaws.lambda.rds;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.json.JSONArray;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LambdaFunctionHandler implements RequestHandler<Object, String> {
	public static final String SQLSERVER_DB_URL_STRING_FORMAT_PORT = "jdbc:sqlserver://";

	@Override
	public String handleRequest(Object input1, Context context) {
		ObjectMapper mapper = new ObjectMapper();
		context.getLogger().log("Input: " + input1);
		List<String> profileIds = new ArrayList<>();
		try {
			String input = mapper.writeValueAsString(input1);
			JsonNode json = mapper.readValue(input, JsonNode.class);
			context.getLogger().log(json.asText());

			System.out.println(json.get("query").asText());
			List<DatabaseModel> listOfRecoreds = executeQuery(json.get("query").asText(), json);
			System.out.println("1");
			context.getLogger().log("Passed\n");
		
			for (DatabaseModel databaseModel : listOfRecoreds) {
				profileIds.add(databaseModel.getValueForProperty("LastName") == null ? ""
						: databaseModel.getValueForProperty("LastName").toString());
			}
			System.out.println("3");

		} catch (IOException e) {
			context.getLogger().log("Failed");
			e.printStackTrace();
		}
		System.out.println(profileIds.size());
		JSONArray array = new JSONArray(profileIds);
		System.out.println(profileIds);
		System.out.println(array);
		return array.toString();
	}

	private String getConnectionString(JsonNode jsonNode) throws IOException {
		System.out.println(jsonNode.get("username").asText());
		return SQLSERVER_DB_URL_STRING_FORMAT_PORT + "database-1.cifi9e9cena7.ap-south-1.rds.amazonaws.com:1433;user="
				+ jsonNode.get("username").asText() + "" + ";password=" + jsonNode.get("password").asText()
				+ ";databaseName=" + jsonNode.get("dbname").asText();
	}

	public List<DatabaseModel> executeQuery(String query, JsonNode json) throws IOException {
		List<DatabaseModel> resultList = new ArrayList<>();
		Statement statement = null;
		ResultSet result = null;
		try {
			Connection connection = DriverManager.getConnection(getConnectionString(json));
			statement = connection.createStatement();
			result = statement.executeQuery(query);
			resultList.addAll(buildDataModelsFromResults(result));
		} catch (SQLException sqle) {
		}
		return resultList;
	}

	private Collection<DatabaseModel> buildDataModelsFromResults(ResultSet result) {
		List<DatabaseModel> resultList = new ArrayList<>();
		try {
			while (result.next()) {
				resultList.add(buildDatabaseModel(result));
			}
		} catch (SQLException sqle) {
		}
		return resultList;
	}

	public static final String VARCHAR = "VARCHAR";
	public static final String INT = "INTEGER";
	public static final String TIMESTAMP = "TIMESTAMP";

	private DatabaseModel buildDatabaseModel(ResultSet result) throws SQLException {
		ResultSetMetaData mData = result.getMetaData();
		DatabaseModel dbModel = new DatabaseModel();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		for (int i = 1; i <= mData.getColumnCount(); i++) {
			String name = mData.getColumnLabel(i);
			String type = mData.getColumnTypeName(i);
			if (VARCHAR.equals(type)) {
				dbModel.addModelProperty(name, result.getString(name));
			} else if (TIMESTAMP.equals(type)) {
				Timestamp value = result.getTimestamp(name);
				dbModel.addModelProperty(name, (value == null) ? "" : dateFormat.format(value));
			} else if (INT.equals(type)) {
				int value = result.getInt(name);
				dbModel.addModelProperty(name, String.valueOf(value));
			} else {
				dbModel.addModelProperty(name, result.getObject(name));
			}
		}
		return dbModel;
	}
}

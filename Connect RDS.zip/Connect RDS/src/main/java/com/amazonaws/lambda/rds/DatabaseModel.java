package com.amazonaws.lambda.rds;

import java.util.HashMap;
import java.util.Map;
public class DatabaseModel {
	private Map<String, Object> modelData = null;
	public DatabaseModel() {
		modelData = new HashMap<>(10);
	}
	public void addModelProperty(String key, Object value) {
		modelData.put(key, value);
	}
	public Object getValueForProperty(String key) {
		return modelData.get(key);
	}
	public boolean isKeyPresent(String key) {
		return modelData.containsKey(key);
	}
}